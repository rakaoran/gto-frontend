#include "definitions.h"

// --- UTILITIES ---
void type_print(const char *text, int speed_ms) {
    for (int i = 0; text[i] != '\0'; i++) {
        printf("%c", text[i]);
        fflush(stdout);
        usleep(speed_ms * 1000); 
    }
}

void ui_clear_screen() { system("clear"); }

void ui_press_enter() {
    printf("\n%s[PRESS ENTER TO RETURN TO MAIN MENU]%s", GRAY, RESET);
    while(getchar() != '\n'); 
    getchar(); 
}

// --- VISUALIZATIONS ---

void ui_run_infection_sim(Grid *g, int patient_zero) {
    printf("\n%s[☠️] INITIATING BIO-DIGITAL ATTACK SEQUENCE...%s\n", RED, RESET);
    usleep(500000);

    int infect_times[MAX_NODES];
    int infect_sources[MAX_NODES];
    
    // CALL LOGIC (Now Time-Aware)
    algo_infection_sim(g, patient_zero, infect_times, infect_sources);

    printf("   %s>>> PATIENT ZERO IDENTIFIED: [%s] <<<%s\n", RED, g->nodes[patient_zero].hostname, RESET);
    printf("   %s-----------------------------------------------%s\n", RED, RESET);

    // Sort nodes by infection time for accurate playback
    int sorted_indices[MAX_NODES];
    int count = 0;
    
    int total_time = 0; 

    for(int i=0; i<g->num_nodes; i++) {
        if(infect_times[i] != INF) {
            sorted_indices[count++] = i;
            if (infect_times[i] > total_time) {
                total_time = infect_times[i];
            }
        }
    }

    // Simple bubble sort for display (N is small)
    for(int i=0; i<count-1; i++) {
        for(int j=0; j<count-i-1; j++) {
            if(infect_times[sorted_indices[j]] > infect_times[sorted_indices[j+1]]) {
                int temp = sorted_indices[j];
                sorted_indices[j] = sorted_indices[j+1];
                sorted_indices[j+1] = temp;
            }
        }
    }

    // ANIMATE RESULTS
    for(int i = 1; i < count; i++) {
        int v = sorted_indices[i];
        int u = infect_sources[v];

        if(u != -1) {
            usleep(200000); 
            printf("   [SPREAD] %s%s%s infected %s%s%s via link (+%dms) [T=%dms]\n", 
                YELLOW, g->nodes[u].hostname, RESET, 
                RED, g->nodes[v].hostname, RESET, 
                g->latency[u][v],
                infect_times[v]);
        }
    }
    
    printf("   %s-----------------------------------------------%s\n", RED, RESET);
    printf("   %s[!] ATTACK COMPLETE. TOTAL UNITS COMPROMISED: %d%s\n", WHITE, count, RESET);
    // NEW: Display the total time
    printf("   %s[⏱️] TOTAL OPERATION TIME: %dms%s\n", YELLOW, total_time, RESET);
}

void ui_run_fastest_path(Grid *g, int start, int target) {
    printf("\n%s[🚀] CALCULATING OPTIMAL ATTACK VECTOR...%s\n", CYAN, RESET);
    
    int dist[MAX_NODES], parent[MAX_NODES];
    
    // CALL LOGIC
    algo_dijkstra(g, start, dist, parent);

    if(dist[target] == INF) {
        printf("   %s[ERROR] TARGET UNREACHABLE. AIR-GAPPED?%s\n", RED, RESET);
    } else {
        printf("   %s[+] PATH FOUND. TOTAL LATENCY: %dms%s\n\n", GREEN, dist[target], RESET);
        
        // Reconstruct path for display
        int path[MAX_NODES], count=0, curr=target;
        while(curr != -1) { 
            path[count++] = curr; 
            curr = parent[curr]; 
        }
        
        printf("   START ");
        for(int i=count-1; i>=0; i--) {
            printf("%s[%s]%s", (i==0?RED:YELLOW), g->nodes[path[i]].hostname, RESET);
            
            if(i > 0) {
                int u = path[i];
                int v = path[i-1];
                printf(" ==(%dms)==> ", g->latency[u][v]);
            }
        }
        printf(" END\n");
    }
}

void ui_run_heatmap(Grid *g) {
    printf("\n%s[🌐] GENERATING GLOBAL LATENCY HEATMAP...%s\n", MAGENTA, RESET);
    
    int dist_matrix[MAX_NODES][MAX_NODES];
    
    // CALL LOGIC (Reusable!)
    algo_floyd_warshall(g, dist_matrix);

    // RENDER
    printf("\n      ");
    for(int i=0; i<g->num_nodes; i++) printf("%s V%02d %s", CYAN, i, RESET);
    printf("\n");
    
    for(int i=0; i<g->num_nodes; i++) {
        printf("   %sV%02d%s ", CYAN, i, RESET);
        for(int j=0; j<g->num_nodes; j++) {
            if(dist_matrix[i][j] == INF) printf("%s --  %s", GRAY, RESET);
            else if(dist_matrix[i][j] == 0) printf("%s 00  %s", WHITE, RESET);
            else printf(" %03d ", dist_matrix[i][j]);
        }
        printf("\n");
    }
}

void ui_run_community_detection(Grid *g) {
    printf("\n%s[🏙️] ANALYZING NETWORK SEGMENTATION...%s\n", BLUE, RESET);
    
    // CALL LOGIC
    algo_find_communities(g);

    // RENDER
    int max_id = 0;
    for(int i=0; i<g->num_nodes; i++) 
        if(g->nodes[i].cluster_id > max_id) max_id = g->nodes[i].cluster_id;

    for(int c=1; c <= max_id; c++) {
        printf("\n   %s>>> CLUSTER #%d DETECTED <<<%s\n", YELLOW, c, RESET);
        for(int i=0; i<g->num_nodes; i++) {
            if(g->nodes[i].cluster_id == c) {
                 printf("     • %s%-15s%s [Type: %s]\n", WHITE, g->nodes[i].hostname, RESET, g->nodes[i].type);
            }
        }
    }
}

void ui_run_backbone_analysis(Grid *g) {
    printf("\n%s[🦴] MAPPING CRITICAL BACKBONE (SMART FOREST)...%s\n", WHITE, RESET);

    // 1. Get Global Distances
    int dist_matrix[MAX_NODES][MAX_NODES];
    algo_floyd_warshall(g, dist_matrix);
    
    // 2. Identify Clusters
    algo_find_communities(g);
    int max_cluster = 0;
    for(int i=0; i<g->num_nodes; i++) 
        if(g->nodes[i].cluster_id > max_cluster) max_cluster = g->nodes[i].cluster_id;

    int total_network_cost = 0;

    // Process each cluster
    for(int c=1; c <= max_cluster; c++) {
        // Collect members
        int members[MAX_NODES];
        int count = 0;
        for(int i=0; i<g->num_nodes; i++)
            if(g->nodes[i].cluster_id == c) members[count++] = i;

        // 3. Find Center (Logic)
        int root = algo_find_cluster_center(g, members, count, dist_matrix);

        // NEW: Calculate the max latency from this root to any node in its cluster
        // This represents the "minimal time to spread" if we start here.
        int broadcast_time = 0;
        for(int k=0; k < count; k++) {
            int node_idx = members[k];
            if (dist_matrix[root][node_idx] != INF && dist_matrix[root][node_idx] > broadcast_time) {
                broadcast_time = dist_matrix[root][node_idx];
            }
        }

        printf("\n   %s>>> CLUSTER %d ROOT ELECTED: %s <<<%s\n", 
            YELLOW, c, g->nodes[root].hostname, RESET);
        // NEW: Print the stat
        printf("   %s>>> OPTIMAL SPREAD TIME: %dms (Furthest node) <<<%s\n", 
            GREEN, broadcast_time, RESET);
            
        printf("   %s----------------------------------------------------------%s\n", GRAY, RESET);

        // 4. Run Prim's (Logic)
        int parent[MAX_NODES], key[MAX_NODES], mst_set[MAX_NODES];
        algo_find_mst_prim(g, root, parent, key, mst_set);

        // Display Edges
        for (int i = 0; i < g->num_nodes; i++) {
            if (g->nodes[i].cluster_id == c && parent[i] != -1) {
                printf("   %-20s  %s<==>%s  %-20s   %s%3dms%s\n", 
                    g->nodes[parent[i]].hostname, 
                    YELLOW, RESET,
                    g->nodes[i].hostname,
                    GREEN, g->latency[i][parent[i]], RESET);
                total_network_cost += g->latency[i][parent[i]];
            }
        }
    }
    printf("\n   %s[i] GLOBAL NETWORK COST (ALL CLUSTERS): %dms%s\n", CYAN, total_network_cost, RESET);
}

void ui_run_cycle_audit(Grid *g) {
    printf("\n%s[🔄] AUDITING NETWORK LOOPS...%s\n", YELLOW, RESET);
    
    int node_a = -1, node_b = -1;
    
    // CALL LOGIC
    bool has_cycle = algo_check_cycles(g, &node_a, &node_b);

    if(!has_cycle) {
        printf("   %s[✓] TOPOLOGY VERIFIED: No loops detected.%s\n", GREEN, RESET);
    } else {
        printf("   %s[!] CYCLE DETECTED:%s Loop closed between %s[%s]%s <--> %s[%s]%s\n", 
                RED, RESET, 
                YELLOW, g->nodes[node_a].hostname, RESET,
                YELLOW, g->nodes[node_b].hostname, RESET);
        printf("\n   %s[⚠️] WARNING: Redundant loops identified above.%s\n", RED, RESET);
    }
}

// --- BASIC RENDERERS ---
void ui_render_topology(Grid *g) {
    printf("\n%s[+] SCANNING NETWORK TOPOLOGY...%s\n", CYAN, RESET);
    usleep(300000); 
    for (int i = 0; i < g->num_nodes; i++) {
        printf(" %s[NODE %02d]%s %-15s :: ", YELLOW, i, RESET, g->nodes[i].hostname);
        
        int connected = 0;
        for (int j = 0; j < g->num_nodes; j++) {
            if (g->latency[i][j] != INF && i != j) {
                printf("%s-->%s%s(%dms)%s ", BLUE, RESET, g->nodes[j].hostname, g->latency[i][j], RESET);
                connected = 1;
            }
        }
        if (!connected) printf("%s[ ISOLATED / OFFLINE ]%s", RED, RESET);
        printf("\n");
        usleep(50000); 
    }
    printf("%s---------------------------------------------------%s\n", CYAN, RESET);
}

void ui_list_nodes(Grid *g) {
    printf("\n%s   Available Network Nodes:%s\n", WHITE, RESET);
    printf("   %s+----+----------------------+----------------+%s\n", GRAY, RESET);
    printf("   | ID | %-20s | %-14s |\n", "HOSTNAME", "TYPE");
    printf("   %s+----+----------------------+----------------+%s\n", GRAY, RESET);
    
    for(int i=0; i < g->num_nodes; i++) {
        printf("   | %s%02d%s | %-20s | %s%-14s%s |\n", 
            CYAN, i, RESET, 
            g->nodes[i].hostname, 
            YELLOW, g->nodes[i].type, RESET);
    }
    printf("   %s+----+----------------------+----------------+%s\n", GRAY, RESET);
}