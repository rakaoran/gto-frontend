#ifndef V2V_CORE_H
#define V2V_CORE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h> 
#include <stdbool.h>

// --- CONSTANTS ---
#define MAX_NODES 20
#define INF 1000000000 

// --- ANSI COLORS (Used only in UI) ---
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define MAGENTA "\033[1;35m"
#define CYAN    "\033[1;36m"
#define WHITE   "\033[1;37m"
#define GRAY    "\033[0;90m"
#define BOLD    "\033[1m"
#define RESET   "\033[0m"

// --- DATA STRUCTURES ---
typedef struct {
    int id;
    char hostname[32]; 
    char type[32];
    int cluster_id; 
    int parent_id; 
} Node;

typedef struct {
    int num_nodes;
    Node nodes[MAX_NODES];
    int latency[MAX_NODES][MAX_NODES]; 
} Grid;

// --- GRAPH LOADING (graph_core.c) ---
void graph_loader_node_names(Grid *g, int count);
void graph_loader_assign_weight(Grid *g, int src, int dest, int ms);
void graph_loader_load_from_file(Grid *g, const char *filename);

// --- ALGORITHMS (algorithms.c - PURE LOGIC) ---
void algo_infection_sim(Grid *g, int start_node, int *infect_times, int *infect_sources);
void algo_dijkstra(Grid *g, int start, int *dist, int *parent);
void algo_floyd_warshall(Grid *g, int dist_matrix[MAX_NODES][MAX_NODES]);
void algo_find_communities(Grid *g); 
void algo_find_mst_prim(Grid *g, int root, int *parent, int *key, int *mst_set);
int algo_find_cluster_center(Grid *g, int *cluster_members, int count, int dist_matrix[MAX_NODES][MAX_NODES]);
bool algo_check_cycles(Grid *g, int *cycle_nodes_a, int *cycle_nodes_b); 

// --- UI MODULE (ui_module.c - STYLING) ---
void ui_clear_screen();
void ui_press_enter();
void ui_list_nodes(Grid *g);
void ui_render_topology(Grid *g);

// Algorithm Wrappers (for consistency haha)
void ui_run_infection_sim(Grid *g, int patient_zero);
void ui_run_fastest_path(Grid *g, int start, int target);
void ui_run_heatmap(Grid *g);
void ui_run_community_detection(Grid *g);
void ui_run_backbone_analysis(Grid *g);
void ui_run_cycle_audit(Grid *g);

#endif