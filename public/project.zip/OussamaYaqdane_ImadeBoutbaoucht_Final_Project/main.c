#include "definitions.h"

int main(int argc, char *argv[]) {
    Grid v2v;

    ui_clear_screen();
    printf("\n%s========================================\n", RED);
    printf("   🚘 V2V THREAT PROPAGATION SYSTEM 🚘   \n");
    printf("     User: Potato (Admin)       \n");
    printf("========================================%s\n", RESET);

    if (argc > 1) {
        graph_loader_load_from_file(&v2v, argv[1]);
        printf("%s[+] NETWORK TOPOLOGY IMPORTED SUCCESSFULLY.%s\n", GREEN, RESET);
    } else {
        printf("%s[i] No input file. Booting default scenario...%s\n", GRAY, RESET);
        graph_loader_node_names(&v2v, 7); 
        graph_loader_assign_weight(&v2v, 0, 1, 15); 
        graph_loader_assign_weight(&v2v, 0, 2, 45); 
        graph_loader_assign_weight(&v2v, 1, 3, 25); 
        graph_loader_assign_weight(&v2v, 2, 3, 90); 
        graph_loader_assign_weight(&v2v, 2, 6, 10); 
        graph_loader_assign_weight(&v2v, 4, 5, 5);  
    }

    ui_render_topology(&v2v);
    
    printf("\n%s[PRESS ENTER TO INITIALIZE COMMAND UPLINK]%s", GRAY, RESET);
    getchar(); 

    int choice, src, dest; 

    while(1) {
        ui_clear_screen();
        printf("\n%s/// SYSTEM CONTROL TERMINAL ///%s\n", WHITE, RESET);
        printf("1. Simulate Infection Wave (Latency-Aware)\n");
        printf("2. Calculate Kill Chain (Dijkstra)\n");
        printf("3. Global Latency Heatmap (Floyd-Warshall)\n");
        printf("4. Isolate Network Communities\n");
        printf("5. Map Critical Backbone (MST)\n");
        printf("6. Audit for Network Cycles\n");
        printf("7. Terminate Session\n");
        printf("%s\nSelect Operation > %s", GREEN, RESET);
        
        if (scanf("%d", &choice) != 1) {
            while(getchar() != '\n'); 
            continue;
        }

        switch(choice) {
            case 1: 
                ui_clear_screen();
                ui_list_nodes(&v2v); 
                printf("\n%s[?] Select Patient Zero ID: %s", YELLOW, RESET);
                scanf("%d", &src);
                if(src >= 0 && src < v2v.num_nodes) ui_run_infection_sim(&v2v, src);
                else printf("%s[!] Invalid Target.%s\n", RED, RESET);
                ui_press_enter();
                break;

            case 2: 
                ui_clear_screen();
                ui_list_nodes(&v2v); 
                printf("\n%s[?] Enter Attacker Node ID: %s", YELLOW, RESET);
                scanf("%d", &src);
                printf("%s[?] Enter Target Node ID: %s", YELLOW, RESET);
                scanf("%d", &dest);
                if(src >= 0 && src < v2v.num_nodes && dest >= 0 && dest < v2v.num_nodes)
                    ui_run_fastest_path(&v2v, src, dest);
                else printf("%s[!] Invalid Coordinates.%s\n", RED, RESET);
                ui_press_enter();
                break;

            case 3: ui_run_heatmap(&v2v); ui_press_enter(); break;
            case 4: ui_run_community_detection(&v2v); ui_press_enter(); break;
            case 5: ui_run_backbone_analysis(&v2v); ui_press_enter(); break;
            case 6: ui_run_cycle_audit(&v2v); ui_press_enter(); break;
            case 7: exit(0);
            default: printf("Invalid Command.\n");
        }
    }
    return 0;
}