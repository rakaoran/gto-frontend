#include "definitions.h"


// Heap Node used to make a priority queue
typedef struct {
    int node_id;
    int cost;
} HeapNode;


// Array wrapper as a min heap
typedef struct {
    HeapNode heap[MAX_NODES * MAX_NODES]; // Size allows for lazy updates
    int size;
} MinHeap;

// Initializes the heap with size 0
void heap_init(MinHeap *pq) {
    pq->size = 0;
}

// Push an int wrapped in a HeapNode to the MinHeap
void heap_push(MinHeap *pq, int node, int cost) {
    int i = pq->size++;
    pq->heap[i].node_id = node;
    pq->heap[i].cost = cost;

    // Heapify up logic, swapping with its parents til the parent's priority is less that its
    while (i > 0) {
        int p = (i - 1) / 2;
        if (pq->heap[p].cost <= pq->heap[i].cost) break;
        HeapNode temp = pq->heap[i];
        pq->heap[i] = pq->heap[p];
        pq->heap[p] = temp;
        i = p;
    }
}

// Pop the Node that has the highest priority (lowest network cost)
HeapNode heap_pop(MinHeap *pq) {
    HeapNode ret = pq->heap[0];
    pq->size--;
    pq->heap[0] = pq->heap[pq->size];

    // Heapify down, swap the new top with its children until no child has a higher priority
    int i = 0;
    while (i * 2 + 1 < pq->size) {
        int child = i * 2 + 1;
        if (child + 1 < pq->size && pq->heap[child + 1].cost < pq->heap[child].cost) {
            child++;
        }
        if (pq->heap[i].cost <= pq->heap[child].cost) break;
        HeapNode temp = pq->heap[i];
        pq->heap[i] = pq->heap[child];
        pq->heap[child] = temp;
        i = child;
    }
    return ret;
}

// Helper function if the heap is empty
int heap_is_empty(MinHeap *pq) {
    return pq->size == 0;
}

// Generic dijkstra algorithm that returns the distances and the parents for backtracking
void dijkstra(Grid *g, int start_node, int *dist_out, int *parent_out) {
    
    // 1. Initialization of the distances array and the min heap
    for (int i = 0; i < g->num_nodes; i++) {
        dist_out[i] = INF;
        if (parent_out) parent_out[i] = -1;
    }
    MinHeap pq;
    heap_init(&pq);
    
    // 2. Set Start
    dist_out[start_node] = 0;
    heap_push(&pq, start_node, 0);

    // 3. Run the dijkstra loop til the heap is empty (each node is processed)
    while (!heap_is_empty(&pq)) {
        HeapNode current = heap_pop(&pq);
        int u = current.node_id;
        int d = current.cost;

        // If we found a shorter path to u before popping this, skip cuz it's useless to re-process
        if (d > dist_out[u]) continue;

        // Iterate Neighbors
        for (int v = 0; v < g->num_nodes; v++) {
            // Check if there is a link between these nodes (valid neighbors)
            if (g->latency[u][v] != INF) {
                int new_dist = dist_out[u] + g->latency[u][v];

                // Relaxation
                if (new_dist < dist_out[v]) {
                    dist_out[v] = new_dist;
                    if (parent_out) parent_out[v] = u;
                    heap_push(&pq, v, new_dist);
                }
            }
        }
    }
}

// MAIN ALGORITHMS

// --- ALGORITHM 1: Infection Simulation ---
// Maps Dijkstra output to "Infection Times" and "Sources"
void algo_infection_sim(Grid *g, int start_node, int *infect_times, int *infect_sources) {
    dijkstra(g, start_node, infect_times, infect_sources);
}

// --- ALGORITHM 2: Standard Dijkstra ---
// Used for finding the fastest path (Kill Chain)
void algo_dijkstra(Grid *g, int start, int *dist, int *parent) {
    dijkstra(g, start, dist, parent);
}

// --- ALGORITHM 3: Floyd-Warshall ---
void algo_floyd_warshall(Grid *g, int dist_matrix[MAX_NODES][MAX_NODES]) {
    // Initialize the distance matrix
    for(int i=0; i < g->num_nodes; i++) {
        for(int j=0; j < g->num_nodes; j++) {
            dist_matrix[i][j] = g->latency[i][j];
        }
    }

    // O(N^3) Core that we did in the class
    for(int k=0; k < g->num_nodes; k++) {
        for(int i=0; i < g->num_nodes; i++) {
            for(int j=0; j < g->num_nodes; j++) {
                if(dist_matrix[i][k] != INF && dist_matrix[k][j] != INF && 
                   dist_matrix[i][k] + dist_matrix[k][j] < dist_matrix[i][j]) {
                    dist_matrix[i][j] = dist_matrix[i][k] + dist_matrix[k][j];
                }
            }
        }
    }
}

// --- ALGORITHM 4: DFS Communities ---
// Normal dfs but each node visited, we assign to it a cluster_id
void dfs_recursive_cluster(Grid *g, int u, int *visited, int cluster_id) {
    visited[u] = 1;
    // assign the cluster id to the node
    g->nodes[u].cluster_id = cluster_id;
    for(int v=0; v < g->num_nodes; v++) {
        if(g->latency[u][v] != INF && !visited[v]) {
            dfs_recursive_cluster(g, v, visited, cluster_id);
        }
    }
}

// Iterate over each node, dfs it and assign the cluster id to its nodes
// If a node is already visited it means that a previous dfs already assigned to it the cluster id, so we skip
void algo_find_communities(Grid *g) {
    int visited[MAX_NODES] = {0};
    int current_cluster = 0;

    for(int i=0; i < g->num_nodes; i++) {
        if(!visited[i]) {
            current_cluster++;
            dfs_recursive_cluster(g, i, visited, current_cluster);
        }
    }
}

// --- ALGORITHM 5: Prim's MST ---

// Find the "center" of a cluster: the node with the smallest eccentricity
// (the one that minimizes the longest distance to any other node in the cluster)

int algo_find_cluster_center(Grid *g, int *cluster_members, int count, int dist_matrix[MAX_NODES][MAX_NODES]) {
    int best_root = -1;
    int min_eccentricity = INF;

    for(int k = 0; k < count; k++) {
        int candidate = cluster_members[k];
        int eccentricity = 0;

        // Calculate how far this candidate is from the farthest node in the cluster
        for(int m = 0; m < count; m++) {
            int peer = cluster_members[m];
            if(dist_matrix[candidate][peer] > eccentricity && dist_matrix[candidate][peer] != INF)
                eccentricity = dist_matrix[candidate][peer];
        }

        // Keep the node with the lowest maximum-distance
        if(eccentricity < min_eccentricity) {
            min_eccentricity = eccentricity;
            best_root = candidate;
        }
    }
    return best_root;
}


// Prim's algorithm (simple O(n²) version) to compute an MST from a given root
void algo_find_mst_prim(Grid *g, int root, int *parent, int *key, int *mst_set) {
    // Initialize all keys as INF, parents undefined, and MST membership false
    for (int i = 0; i < g->num_nodes; i++) { 
        key[i] = INF; 
        parent[i] = -1; 
        mst_set[i] = 0;
    }
    key[root] = 0; // Start MST from the chosen root

    // Build the MST by adding one node at each iteration
    for (int count = 0; count < g->num_nodes - 1; count++) {
        int min = INF, u = -1;

        // Pick the non-MST node with the smallest key
        for (int v = 0; v < g->num_nodes; v++) {
            if (!mst_set[v] && key[v] < min) { 
                min = key[v]; 
                u = v; 
            }
        }

        if (u == -1) break; // Disconnected graph safety check
        mst_set[u] = 1;      // Include node in MST

        // Update neighbors: if edge (u,v) is better than current key[v], take it
        for (int v = 0; v < g->num_nodes; v++) {
            if (g->latency[u][v] != INF && !mst_set[v] && g->latency[u][v] < key[v]) {
                parent[v] = u; 
                key[v] = g->latency[u][v];
            }
        }
    }
}


// --- ALGORITHM 6: Cycle Detection (Undirected) ---

// Recursive helper: Just needs 'visited' and 'parent'
bool check_cycle_recursive_dfs_helper(Grid *g, int starting_vertex, int *visited, int parent, int *node_a, int *node_b) {
    visited[starting_vertex] = 1;
    
    for(int vertex = 0; vertex < g->num_nodes; vertex++) {
        // Check if edge exists and not self-loop
        if(g->latency[starting_vertex][vertex] != INF && starting_vertex != vertex) {
            
            if(!visited[vertex]) {
                // Recurse, passing 'u' as the new parent
                if(check_cycle_recursive_dfs_helper(g, vertex, visited, starting_vertex, node_a, node_b)) {
                    return true;
                }
            } 
            // If v is visited AND it's not the node we just came from, then we have a cycle
            else if (vertex != parent) {
                // node_a and node_b are two nodes participating in the cycle, returning them just for visuals
                *node_a = parent;
                *node_b = vertex;
                return true;
            }
        }
    }
    return false;
}

bool algo_check_cycles(Grid *g, int *cycle_nodes_a, int *cycle_nodes_b) {
    int visited[MAX_NODES] = {0};

    // Iterate all nodes to handle disconnected clusters, skip if a node is visited cuz it and its cluster members has been handled in previous dfs
    for(int i = 0; i < g->num_nodes; i++) {
        if(!visited[i]) {
            // Start DFS with parent -1 (no parent)
            if(check_cycle_recursive_dfs_helper(g, i, visited, -1, cycle_nodes_a, cycle_nodes_b)) {
                return true;
            }
        }
    }
    return false;
}