#include "definitions.h"

void graph_loader_node_names(Grid *g, int count)
{
    g->num_nodes = count;

    const char *names[20] = {
        "OVERLORD_AI", "TESLA_X_V2", "CYBER_TRUCK", "AMBULANCE_DRONE",
        "POLICE_INTERCEPT", "5G_MAIN_HUB", "GHOST_RIDER", "WAYMO_TAXI_BETA",
        "AMAZON_PRIME_AIR", "TRAFFIC_CTRL_NET", "SUPERCHARGER_X", "BAT_TUMBLER",
        "SCHOOL_BUS_E", "LIME_SCOOTER_77", "RIVIAN_R1T_CAMP", "FORD_F150_LIGHT",
        "FEDEX_ROBOT_DG", "UBER_FLYING_TAXI", "NEWS_CHOPPER_6", "STREET_CLEANER_AI"};

    const char *types[20] = {
        "SERVER", "EV_SUV", "TRUCK", "EMERGENCY",
        "AUTHORITY", "INFRA_HUB", "BIKE", "ROBOTAXI",
        "DELIVERY_DRONE", "INFRA_LIGHTS", "POWER_GRID", "ASSAULT_VEH",
        "TRANSPORT", "RENTAL", "ADVENTURE", "PICKUP",
        "LAST_MILE_BOT", "VTOL_AIRCRAFT", "MEDIA_UNIT", "SERVICE_BOT"};

    for (int i = 0; i < count; i++)
    {
        g->nodes[i].id = i;
        g->nodes[i].cluster_id = 0;
        g->nodes[i].parent_id = -1;

        if (i < 20)
        {
            strcpy(g->nodes[i].hostname, names[i]);
            strcpy(g->nodes[i].type, types[i]);
        }
        else
        {
            sprintf(g->nodes[i].hostname, "UNKNOWN_UNIT_%02d", i);
            strcpy(g->nodes[i].type, "GENERIC");
        }

        for (int j = 0; j < count; j++)
        {
            g->latency[i][j] = (i == j) ? 0 : INF;
        }
    }
}

void graph_loader_assign_weight(Grid *g, int src, int dest, int ms)
{
    if (src < 0 || src >= g->num_nodes || dest < 0 || dest >= g->num_nodes)
        return;
    g->latency[src][dest] = ms;
    g->latency[dest][src] = ms;
}

void graph_loader_load_from_file(Grid *g, const char *filename)
{
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("%s[!] FATAL: Could not open file '%s'%s\n", RED, filename, RESET);
        exit(1);
    }

    int file_count; // The actual count in the file
    if (fscanf(f, "%d", &file_count) != 1) {
        printf("%s[!] Invalid file format (Header missing).%s\n", RED, RESET);
        fclose(f);
        exit(1);
    }

    // Determine how many nodes we can actually store
    int effective_count = file_count;
    if (effective_count > MAX_NODES) {
        printf("%s[!] Warning: File contains %d nodes. Truncating to %d.%s\n", 
               YELLOW, file_count, MAX_NODES, RESET);
        effective_count = MAX_NODES;
    }

    // Initialize the struct with the safe count
    graph_loader_node_names(g, effective_count);

    for (int i = 0; i < file_count; i++)
    {
        for (int j = 0; j < file_count; j++)
        {
            int val;
            if (fscanf(f, "%d", &val) != 1) {
                printf("%s[!] Error reading matrix data at [%d][%d].%s\n", RED, i, j, RESET);
                fclose(f);
                exit(1);
            }

            // Only store the data if it fits in our 20x20 grid
            if (i < effective_count && j < effective_count) {
                if (val == -1 || val < 0) val = INF;
                g->latency[i][j] = val;
            }
        }
    }
    fclose(f);
}