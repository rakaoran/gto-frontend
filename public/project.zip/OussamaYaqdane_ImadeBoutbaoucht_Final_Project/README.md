# Project

## How to Compile

```text
gcc main.c algorithms.c graph_loader.c ui_module.c -o main
```

## How to run

```text
./main graph.txt
```

## AI Usage

The algorithms in `algorithms.c` were independently implemented, AI help was used only with styling and coloring to make the program interactive and engaging, and of course, sample matrix generation.
